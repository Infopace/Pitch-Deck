# Pitch deck designs — Volume 2

Ten pitch deck designs. Each has its own layout on every slide, not just its own colours. Every design has the same 14 slide types, all filled with the same sample company (Flowmark).

## What's in the pack

```
pitch-deck-designs/
  designs.json            manifest of all 10 designs (id, name, fonts, key colours, paths)
  sample-content.json     the sample text and figures used on every slide, grouped by slide type
  01-swiss-grid/
    deck.html             the full deck: grid view; click a slide to present, arrow keys to move, Esc to exit
    theme.json            fonts (with Google Fonts URLs), colour palette, list of slides with speaker notes
    slides/01-cover.html  each slide as a standalone 1920×1080 page (fonts included, scales to the window)
    sections/01-cover.html  the raw <section> markup of each slide, for importing into your own renderer
  02-editorial/ … 10-split-panel/   same structure
```

| # | Design | Look | Fonts |
|---|--------|------|-------|
| 01 | Swiss Grid | Hairline rules, huge numerals, one signal red | Work Sans |
| 02 | Editorial | Magazine serif, italics, ledger figures | Fraunces, Work Sans |
| 03 | Bold Poster | Condensed caps, yellow and charcoal blocks | Oswald, Work Sans |
| 04 | Bento Pastel | Rounded pastel tile grids | Syne, Work Sans |
| 05 | Boardroom | Consulting style: action titles, tracker, sources | Georgia, Arial (system) |
| 06 | Terminal | Dark developer-tool look, console windows | Courier New, Work Sans |
| 07 | Soft Gradient | Pastel gradient, frosted cards, pills | Work Sans |
| 08 | Blueprint | Grid paper, dashed lines, title block | Oswald, Courier New, Work Sans |
| 09 | Noir Luxe | Black and ivory, gold hairlines, centred | Fraunces, Work Sans |
| 10 | Split Panel | Coloured title panel beside the content | Work Sans |

## The 14 slide types (same order in every design)

01 cover · 02 summary · 03 problem · 04 solution · 05 product · 06 market · 07 model · 08 traction · 09 competition · 10 roadmap · 11 gallery · 12 team · 13 ask · 14 closing

## Using them in your tool

- **Slide format.** Every slide is 1920×1080 px with 128 px margins. All styling is inline, so each file stands on its own. The only external dependency is the Google Fonts stylesheet, linked in each page's `<head>` and listed in `theme.json`.
- **Rendering `sections/`.** If you render the raw section markup yourself, apply the base CSS found in the `<style>` block of any `slides/*.html` file. It covers the reset, the default heading sizes, and treating a `div` with no `display` set as a flex column. The raw sections also use three custom tags from the editor they were designed in: `<x-icon>`, `<x-shape>` and `<x-connector>`. The files in `slides/` and `deck.html` already have these converted to plain SVG and HTML, so use those if your renderer is plain HTML.
- **Content.** The sample text is written into the markup. To generate decks from user input, swap the text in each slide. `sample-content.json` lists every field by slide type, which helps map your input fields onto each slide. Keep text lengths close to the sample; the layouts are sized for it.
- **Images.** The gallery slides use labelled placeholder boxes such as `[Dashboard screenshot]`. Replace each box with an `<img>` of the same size, using `object-fit:cover`.
- **Export.** Headless Chrome (Playwright or Puppeteer) at a 1920×1080 viewport captures each file in `slides/` as a PNG or PDF page. That's also the easiest way to make thumbnails for a design gallery.
- **Sample figures.** The numbers and names on the slides are placeholders, not real data.
